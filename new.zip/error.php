<!DOCTYPE html>
<html lang='en'>
<head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Error</title>
    <link type='text/css' rel='stylesheet' href='css/style.css'>
</head>
<body>
<div class='wrap_block_success'>
    <div class='block_success'>
        <h2>Error! An error occurred while creating the order</h2>
        <h2>Try again</h2>
    </div>
</div>
</body>
</html>
